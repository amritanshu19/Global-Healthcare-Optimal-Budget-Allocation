#include<bits/stdc++.h>
using namespace std;

int main(){
    //x11 = p.LpVariable("x11", lowBound = 0)
    freopen("output.txt", "w", stdout);

    for(int i=1; i<=10; i++){
        for(int j=1; j<=10; j++){
            cout<<"x"<<i<<j<<" = p.LpVariable(\"x"<<i<<j<<"\", lowBound = 0)"<<endl;
        
    }
    }
    return 0;
}
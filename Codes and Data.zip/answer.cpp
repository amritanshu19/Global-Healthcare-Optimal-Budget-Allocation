#include<bits/stdc++.h>
using namespace std;

int main(){
    //print(p.value(xij), p.value(y), p.value(Lp_prob.objective)) 
    freopen("answer_output.txt", "w", stdout);
    cout<<"print(";
    for(int i=1; i<=10; i++){
        for(int j=1; j<=10; j++){
            cout<<"p.value(x"<<i<<j<<"), ";
        
    }
   
    }
     cout<<"p.value(Lp_prob.objective))";
    return 0;
}